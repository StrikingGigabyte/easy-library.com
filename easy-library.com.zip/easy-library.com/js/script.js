document.addEventListener('DOMContentLoaded', function() {
    var tabLinks = document.querySelectorAll('.tab-link');
    var tabContents = document.querySelectorAll('.tab-content');
    var questions = document.querySelectorAll('.faq-question');
    var searchInput = document.getElementById('search');
    var headerContainer = document.querySelector('.header-container');
    var prevScrollpos = window.pageYOffset;

    tabLinks.forEach(function(link) {
        link.addEventListener('click', function() {
            var tabId = this.getAttribute('data-tab');

            tabLinks.forEach(function(link) {
                link.classList.remove('active');
            });

            tabContents.forEach(function(content) {
                content.classList.remove('active');
            });

            this.classList.add('active');
            document.getElementById(tabId).classList.add('active');
        });
    });

    questions.forEach(function(question) {
        question.addEventListener('click', function() {
            var answer = this.nextElementSibling;
            var isActive = question.classList.contains('active');

            questions.forEach(function(q) {
                q.classList.remove('active');
                q.nextElementSibling.style.display = 'none';
            });

            if (!isActive) {
                question.classList.add('active');
                answer.style.display = 'block';
            }
        });
    });

    searchInput.addEventListener('input', function() {
        var filter = searchInput.value.toLowerCase();
        questions.forEach(function(question) {
            var questionText = question.textContent.toLowerCase();
            var answer = question.nextElementSibling;
            if (questionText.includes(filter)) {
                question.style.display = '';
                answer.style.display = 'none';
            } else {
                question.style.display = 'none';
                answer.style.display = 'none';
            }
        });
    });

    window.addEventListener('scroll', function() {
        var currentScrollPos = window.pageYOffset;
        if (currentScrollPos > prevScrollpos) {
            headerContainer.classList.add('shrink');
        } else {
            headerContainer.classList.remove('shrink');
        }
        prevScrollpos = currentScrollPos;
    });
});
