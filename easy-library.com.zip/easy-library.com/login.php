<?php
session_start();

// Установите время жизни сессии в 12 часов (12 * 60 * 60 секунд)
$session_lifetime = 12 * 60 * 60; 
ini_set('session.cookie_lifetime', $session_lifetime);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if ($_POST['username'] == 'support' && $_POST['password'] == 'oXSALkOK') {
        $_SESSION['loggedin'] = true;
        $_SESSION['start_time'] = time(); // Записываем время начала сессии
        header('Location: index.php');
        exit;
    } else {
        $error = 'Invalid credentials';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/adm.css">
    <meta name="robots" content="noindex, nofollow">
</head>
<body>
    <div class="login-container">
        <form method="post" action="login.php" class="login-form">
            <h2>Login</h2>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            <br>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <br>
            <button type="submit">Login</button>
        </form>
        <?php if (isset($error)) echo '<p class="error">' . $error . '</p>'; ?>
    </div>
</body>
</html>
